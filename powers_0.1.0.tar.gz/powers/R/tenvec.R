#' Integer vector from 1 to 10
#'
#' Self-explanatory!
#' @format This (and the next) is a new tag that applies for data documentation.
#' @source Note that you shouldn't use the `@export` tag when documenting data!
"tenvec"
